<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php $title = "Server Information"; ?>